instruction for using the Adblocker:

Chrome Browser:
1.First go to this link: chrome://extensions/
2.You Will find a switch in your right side (Developer mode) and just click it
3.Now you will find 3 switches in your left side, you will click on the Button: (Load Unpacked)
And your done

Brave Browser:
1.First go to this link: brave://extensions/
2.You Will find a switch in your right side (Developer mode) and just click it
3.Now you will find 3 switches in your left side, you will click on the Button: (Load Unpacked)
And your done

Microsoft Edge:
1.First go to this link: edge://extensions/
2.You Will find a switch in your left side (Developer mode) and just click it
3.Now you will find 3 switches in the middle, you will click on the Button: (Load Unpacked)
And your done

Firefox:
Link: https://addons.mozilla.org/en-US/firefox/addon/light-version-ad-blocker/
